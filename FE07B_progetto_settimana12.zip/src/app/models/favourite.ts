export interface Favourite {
  movieId: number;
  userId: number;
  id: number;
}
